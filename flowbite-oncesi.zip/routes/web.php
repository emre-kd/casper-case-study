<?php

use Illuminate\Support\Facades\Route;
use Inertia\Inertia;
use App\Http\Controllers\SlideController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\FormController;

use App\Models\Slide;


Route::get('/', function () {
    $slides = Slide::all();
    return Inertia::render('Welcome', [
        'slides' => $slides
    ]);
})->name('home');



Route::middleware(['auth'])->prefix('admin')->group(function () {

    Route::get('dashboard', function () {
    return Inertia::render('Dashboard');
})->name('dashboard');

Route::resource('slides', SlideController::class);
Route::resource('products', ProductController::class);
Route::resource('forms', FormController::class);



});


require __DIR__.'/settings.php';
require __DIR__.'/auth.php';
